<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GIS_Dashboard extends CI_Controller {
    
	function __construct(){
        parent :: __construct();
        $this->load->model('Gis_server','g');
        $this->load->model('Gis_server');
        $this->load->helper(array('form', 'url'));
        session_start();
        
	}

	public function index()
	{
        $date = date('Y-m-d');
        $uid = $_SESSION['index'];
        $data['script'] = $this->load->view('include/script.php',NULL,TRUE);
        $data['style'] = $this->load->view('include/styleGIS.php',NULL,TRUE);
        $data['akses'] = json_encode($this->g->getAkses($uid));
        $data['galery'] =  json_encode($this->g->getGaleryImage($date));
        $data['detailLokasi'] = json_encode($this->g->getDetailLokasi());
        $this->load->view('GIS/Dashboard.php', $data);
    }

    public function NDVI(){
        $uid = $_SESSION['index'];
        $authorization = $this->g->getAuthorization($uid);
        $page = $this->input->get('page');
        $loc = $this->input->get('loc');
        $currLoc = $this->input->get('currLoc');
        $date = $this->input->get('date');
        if($date != null){
            $date = str_replace("_"," ",$date);
        }
        $data['loc'] = $loc;
        $data['page'] = $page;
        $data['currLoc'] = $currLoc;
        $data['pageDate'] = $date;
        $data['subpage'] = 'NDVI';
		$data['script'] = $this->load->view('include/script.php',NULL,TRUE);
		$data['style'] = $this->load->view('include/styleGIS.php',NULL,TRUE);
		$data['header'] = $this->load->view('template/GIS/header.php',NULL,TRUE);	
		$data['modal'] =  $this->load->view('template/logoutModal.php',NULL,TRUE);	
        if($loc == 'PG'){
            if($currLoc == null){
                $pictLoc = "PG1";
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbar.php', array('currLoc' => $currLoc, 'authorization' => $authorization), TRUE);
            if($page == 'HOME'){
                $data['picts'] = $this->g->getPict('NDVI','NDVI',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('NDVI','NDVI',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'NDVI'));
                $this->load->view('GIS/NDVI/PG/Home.php', $data);
            }else if($page == 'PW'){
                $data['picts'] = $this->g->getPict('NDVI','Plant Weight',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('NDVI','Plant Weight',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Plant Weight'));
                $this->load->view('GIS/NDVI/PG/plantWeight.php', $data);
            }else if($page == 'PD'){
                $data['picts'] = $this->g->getPict('NDVI','Plant Disease',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('NDVI','Plant Disease',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Plant Disease'));
                $this->load->view('GIS/NDVI/PG/plantDisease.php', $data);
            }else if($page == 'SOW'){
                $data['picts'] = $this->g->getPict('NDVI','Sufficiency Of Water',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('NDVI','Sufficiency Of Water',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Sufficiency Of Water'));
                // $data['tester'] = json_encode($this->g->getAllTableLocation());
                $this->load->view('GIS/NDVI/PG/sufficiencyOfWater.php', $data);
            }else if($page == 'SUG'){
                $data['allPicts'] = $this->g->getAllPict('NDVI','Suggestion',$pictLoc);
                
                $this->load->view('GIS/NDVI/PG/suggestion.php', $data);
            }
            
        }else if($loc == 'Wilayah'){
            if($currLoc == null){
                $pictLoc = "W01";
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbarWilayah.php', array('currLoc' => $currLoc, 'authorization' => $authorization), TRUE);
            if($page == 'HOME'){
                $data['picts'] = $this->g->getPict('NDVI','NDVI',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('NDVI','NDVI',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'NDVI'));
                $this->load->view('GIS/NDVI/Wilayah/Home.php', $data);
            }else if($page == 'PW'){
                $data['picts'] = $this->g->getPict('NDVI','Plant Weight',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('NDVI','Plant Weight',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Plant Weight'));
                $this->load->view('GIS/NDVI/Wilayah/plantWeight.php', $data);
            }else if($page == 'PD'){
                $data['picts'] = $this->g->getPict('NDVI','Plant Disease',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('NDVI','Plant Disease',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Plant Disease'));
                $this->load->view('GIS/NDVI/Wilayah/plantDisease.php', $data);
            }else if($page == 'SOW'){
                $data['picts'] = $this->g->getPict('NDVI','Sufficiency Of Water',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('NDVI','Sufficiency Of Water',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Sufficiency Of Water'));
                $this->load->view('GIS/NDVI/Wilayah/sufficiencyOfWater.php', $data);
            }else if($page == 'SUG'){
                $data['allPicts'] = $this->g->getAllPict('NDVI','Suggestion',$pictLoc);
                 $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'NDVI'));
                $this->load->view('GIS/NDVI/Wilayah/suggestion.php', $data);
            }
        }else if($loc == 'Lokasi'){
            $listLokasi = $this->g->getLokasi();
            if($currLoc == null){
                $pictLoc = $listLokasi[0]->lokasi;
            }else{
                $pictLoc = $currLoc;
            }
            
            $data['navbar'] = $this->load->view('template/GIS/navbarLokasi.php',array('currLoc' => $currLoc, 'authorization' => $authorization, 'listLokasi' =>$listLokasi), TRUE);
            if($page == 'HOME'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('NDVI','NDVI',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('NDVI','NDVI',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('NDVI','NDVI',$pictLoc);
                $this->load->view('GIS/NDVI/Lokasi/Home.php', $data);
            }else if($page == 'PW'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('NDVI','Plant Weigt',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('NDVI','Plant Weight',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('NDVI','Plant Weight',$pictLoc);
                $this->load->view('GIS/NDVI/Lokasi/plantWeight.php', $data);
            }else if($page == 'PD'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('NDVI','Plant Disease',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('NDVI','Plant Disease',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('NDVI','Plant Disease',$pictLoc);
                $this->load->view('GIS/NDVI/Lokasi/plantDisease.php', $data);
            }else if($page == 'SOW'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('NDVI','Sufficiency Of Water',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('NDVI','Sufficiency Of Water',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('NDVI','Sufficiency Of Water',$pictLoc);
                $this->load->view('GIS/NDVI/Lokasi/sufficiencyOfWater.php', $data);
            }else if($page == 'SUG'){
                $data['allPicts'] = $this->g->getAllPict('NDVI','Suggestion',$pictLoc);
                $this->load->view('GIS/NDVI/Lokasi/suggestion.php', $data);
            }
        }
    }
    
    public function DSM(){
        $uid = $_SESSION['index'];
        $authorization = $this->g->getAuthorization($uid);
        $page = $this->input->get('page');
        $loc = $this->input->get('loc');
        $currLoc = $this->input->get('currLoc');
        $date = $this->input->get('date');
        if($date != null){
            $date = str_replace("_"," ",$date);
        }
        $data['loc'] = $loc;
        $data['page'] = $page;
        $data['currLoc'] = $currLoc;
        $data['pageDate'] = $date;
        $data['subpage'] = 'DSM';
		$data['script'] = $this->load->view('include/script.php',NULL,TRUE);
		$data['style'] = $this->load->view('include/styleGIS.php',NULL,TRUE);
		$data['header'] = $this->load->view('template/GIS/header.php',NULL,TRUE);
        $data['modal'] =  $this->load->view('template/logoutModal.php',NULL,TRUE);
        if($loc == "PG"){
            if($currLoc == null){
                $pictLoc = "PG1";
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbar.php', array('currLoc' => $currLoc, 'authorization' => $authorization), TRUE);		
            if($page == 'HOME'){
                $data['picts'] = $this->g->getPict('DSM','DSM',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','DSM',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'DSM'));
                $this->load->view('GIS/DSM/PG/Home.php', $data);
            }else if($page == 'WF'){
                $data['picts'] = $this->g->getPict('DSM','Water Flow',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Flow',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Water Flow'));
                $this->load->view('GIS/DSM/PG/waterFlow.php', $data);
            }else if($page == 'WD'){
                $data['picts'] = $this->g->getPict('DSM','Water Direction',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Direction',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Water Direction'));
                $this->load->view('GIS/DSM/PG/waterDirection.php', $data);
            }else if($page == 'WL'){
                $data['picts'] = $this->g->getPict('DSM','Water Logging',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Logging',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Water Logging'));
                $this->load->view('GIS/DSM/PG/waterLogging.php', $data);
            }else if($page == 'RGB'){
                $data['picts'] = $this->g->getPict('DSM','RGB',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','RGB',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'RGB'));
                $this->load->view('GIS/DSM/PG/RGB.php', $data);
            }else if($page == "DL"){
                $data['picts'] = $this->g->getPict('DSM','Design Location',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Design Location',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Design Location'));
                $this->load->view('GIS/DSM/PG/DesignLocation.php', $data);
            }else if($page == "DD"){
                $data['picts'] = $this->g->getPict('DSM','Design Deal',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Design Deal',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Design Deal'));
                $this->load->view('GIS/DSM/PG/DesignDeal.php', $data);
            }
        }else if($loc == "Wilayah"){
            if($currLoc == null){
                $pictLoc = "W01";
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbarWilayah.php', array('currLoc' => $currLoc, 'authorization' => $authorization), TRUE);		
            if($page == 'HOME'){
                $data['picts'] = $this->g->getPict('DSM','DSM',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','DSM',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'DSM'));
                $this->load->view('GIS/DSM/Wilayah/Home.php', $data);
            }else if($page == 'WF'){
                $data['picts'] = $this->g->getPict('DSM','Water Flow',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Flow',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Water Flow'));
                $this->load->view('GIS/DSM/Wilayah/waterFlow.php', $data);
            }else if($page == 'WD'){
                $data['picts'] = $this->g->getPict('DSM','Water Direction',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Direction',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Water Direction'));
                $this->load->view('GIS/DSM/Wilayah/waterDirection.php', $data);
            }else if($page == 'WL'){
                $data['picts'] = $this->g->getPict('DSM','Water Logging',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Logging',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Water Logging'));
                $this->load->view('GIS/DSM/Wilayah/waterLogging.php', $data);
            }else if($page == 'RGB'){
                $data['picts'] = $this->g->getPict('DSM','RGB',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','RGB',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'RGB'));
                $this->load->view('GIS/DSM/Wilayah/RGB.php', $data);
            }else if($page == "DL"){
                $data['picts'] = $this->g->getPict('DSM','Design Location',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Design Location',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Design Location'));
                $this->load->view('GIS/DSM/Wilayah/DesignLocation.php', $data);
            }else if($page == "DD"){
                $data['picts'] = $this->g->getPict('DSM','Design Deal',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('DSM','Design Deal',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Design Deal'));
                $this->load->view('GIS/DSM/Wilayah/DesignDeal.php', $data);
            }
        }else if($loc == "Lokasi"){
            $listLokasi = $this->g->getLokasi();
            if($currLoc == null){
                $pictLoc = $listLokasi[0]->lokasi;
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbarLokasi.php',array('currLoc' => $currLoc, 'authorization' => $authorization, 'listLokasi' =>$listLokasi), TRUE);	
            if($page == 'HOME'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('DSM','DSM',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('DSM','DSM',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('DSM','DSM',$pictLoc);
                $this->load->view('GIS/DSM/Lokasi/Home.php', $data);
            }else if($page == 'WF'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('DSM','Water Flow',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('DSM','Water Flow',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Flow',$pictLoc);
                $this->load->view('GIS/DSM/Lokasi/waterFlow.php', $data);
            }else if($page == 'WD'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('DSM','Water Direction',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('DSM','Water Direction',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Direction',$pictLoc);
                $this->load->view('GIS/DSM/Lokasi/waterDirection.php', $data);
            }else if($page == 'WL'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('DSM','Water Logging',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('DSM','Water Logging',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('DSM','Water Logging',$pictLoc);
                $data['chartData'] =  isset($data['picts'][0]->photo_id) ?json_encode($this->g->getWaterLogging($data['picts'][0]->photo_id)) :json_encode(array(array("Dry"=>0, "Moist"=>0, "Wet"=>0, "Very_Wet"=>0, "Flood"=>0)));
                $this->load->view('GIS/DSM/Lokasi/waterLogging.php', $data);
            }else if($page == "RGB"){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('DSM','RGB',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('DSM','RGB',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('DSM','RGB',$pictLoc);
                $this->load->view('GIS/DSM/Lokasi/RGB.php', $data);
            }else if($page == "DL"){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('DSM','Design Location',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('DSM','Design Location',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('DSM','Design Location',$pictLoc);
                $this->load->view('GIS/DSM/Lokasi/DesignLocation.php', $data);
            }else if($page == "DD"){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('DSM','Design Deal',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('DSM','Design Deal',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('DSM','Design Deal',$pictLoc);
                $this->load->view('GIS/DSM/Lokasi/DesignDeal.php', $data);
            }
        }
    }

    public function Sensor(){
        $uid = $_SESSION['index'];
        $authorization = $this->g->getAuthorization($uid);
        $page = $this->input->get('page');
        $loc = $this->input->get('loc');
        $currLoc = $this->input->get('currLoc');
        $date = $this->input->get('date');
        if($date != null){
            $date = str_replace("_"," ",$date);
        }
        $data['loc'] = $loc;
        $data['page'] = $page;
        $data['currLoc'] = $currLoc;
        $data['pageDate'] = $date;
        $data['subpage'] = 'Sensor';
		$data['script'] = $this->load->view('include/script.php',NULL,TRUE);
		$data['style'] = $this->load->view('include/styleGIS.php',NULL,TRUE);
		$data['header'] = $this->load->view('template/GIS/header.php',NULL,TRUE);	
        $data['modal'] =  $this->load->view('template/logoutModal.php',NULL,TRUE);	
        if($loc == 'PG'){
            if($currLoc == null){
                $pictLoc = "PG1";
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbar.php', array('currLoc' => $currLoc, 'authorization' => $authorization), TRUE);
            if($page == 'LWL'){
                $data['picts'] = $this->g->getPict('Sensor','Lagoon Water Level',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Lagoon Water Level',$pictLoc);
                $this->load->view('GIS/Sensor/PG/lagoonWaterLevel.php', $data);
            }else if($page == 'RF'){
                $data['picts'] = $this->g->getPict('Sensor','Rainfall',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Rainfall',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Rainfall'));
                $this->load->view('GIS/Sensor/PG/rainfall.php', $data);
            }else if($page == 'TM'){
                $data['picts'] = $this->g->getPict('Sensor','Temperature',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Temperature',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Temperature'));
                $this->load->view('GIS/Sensor/PG/temperature.php', $data);
            }else if($page == 'HU'){
                $data['picts'] = $this->g->getPict('Sensor','Humidity',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Humidity',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Humidity'));
                $this->load->view('GIS/Sensor/PG/humidity.php', $data);
            }else if($page == 'SM'){
                $data['picts'] = $this->g->getPict('Sensor','Soil Moisture',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Soil Moisture',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Soil Moisture'));
                $this->load->view('GIS/Sensor/PG/soilMoisture.php', $data);
            }
        }else if($loc == "Wilayah"){
            if($currLoc == null){
                $pictLoc = "W01";
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbarWilayah.php',array('currLoc' => $currLoc, 'authorization' => $authorization),TRUE);
            if($page == 'LWL'){
                $data['picts'] = $this->g->getPict('Sensor','Lagoon Water Level',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Lagoon Water Level',$pictLoc);
                
                $this->load->view('GIS/Sensor/Wilayah/lagoonWaterLevel.php', $data);
            }else if($page == 'RF'){
                $data['picts'] = $this->g->getPict('Sensor','Rainfall',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Rainfall',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Rainfall'));
                $this->load->view('GIS/Sensor/Wilayah/rainfall.php', $data);
            }else if($page == 'TM'){
                $data['picts'] = $this->g->getPict('Sensor','Temperature',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Temperature',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Temperature'));
                $this->load->view('GIS/Sensor/Wilayah/temperature.php', $data);
            }else if($page == 'HU'){
                $data['picts'] = $this->g->getPict('Sensor','Humidity',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Humidity',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Humidity'));
                $this->load->view('GIS/Sensor/Wilayah/humidity.php', $data);
            }else if($page == 'SM'){
                $data['picts'] = $this->g->getPict('Sensor','Soil Moisture',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Sensor','Soil Moisture',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Soil Moisture'));
                $this->load->view('GIS/Sensor/Wilayah/soilMoisture.php', $data);
            }
        }else if($loc == "Lokasi"){
            $listLokasi = $this->g->getLokasi();
            if($currLoc == null){
                $pictLoc = $listLokasi[0]->lokasi;
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbarLokasi.php',array('currLoc' => $currLoc, 'authorization' => $authorization, 'listLokasi' =>$listLokasi), TRUE);
            if($page == 'RF'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('Sensor','Rainfall',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('Sensor','Rainfall',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('Sensor','Rainfall',$pictLoc);
                $this->load->view('GIS/Sensor/Lokasi/rainfall.php', $data);
            }else if($page == 'TM'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('Sensor','Temperature',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('Sensor','Temperature',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('Sensor','Temperature',$pictLoc);
                $this->load->view('GIS/Sensor/Lokasi/temperature.php', $data);
            }else if($page == 'HU'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('Sensor','Humidity',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('Sensor','Humidity',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('Sensor','Humidity',$pictLoc);
                $this->load->view('GIS/Sensor/Lokasi/humidity.php', $data);
            }else if($page == 'SM'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('Sensor','Soil Moisture',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('Sensor','Soil Moisture',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('Sensor','Soil Moisture',$pictLoc);
                $this->load->view('GIS/Sensor/Lokasi/soilMoisture.php', $data);
            }
        }
       
		
    }

    public function Other(){
        $uid = $_SESSION['index'];
        $authorization = $this->g->getAuthorization($uid);
        $page = $this->input->get('page');
        $loc = $this->input->get('loc');
        $currLoc = $this->input->get('currLoc');
        $date = $this->input->get('date');
        if($date != null){
            $date = str_replace("_"," ",$date);
        }
        $data['loc'] = $loc;
        $data['page'] = $page;
        $data['subpage'] = 'Other';
        $data['currLoc'] = $currLoc;
        $data['pageDate'] = $date;
		$data['script'] = $this->load->view('include/script.php',NULL,TRUE);
		$data['style'] = $this->load->view('include/styleGIS.php',NULL,TRUE);
		$data['header'] = $this->load->view('template/GIS/header.php',NULL,TRUE);
        $data['modal'] =  $this->load->view('template/logoutModal.php',NULL,TRUE);	
        if($loc == "PG"){
            if($currLoc == null){
                $pictLoc = "PG1";
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbar.php',array('currLoc' => $currLoc, 'authorization' => $authorization),TRUE);	
            if($page == 'ST'){
                $data['picts'] = $this->g->getPict('Other','Soil Texture',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Other','Soil Texture',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Soil Texture'));
                $this->load->view('GIS/Other/PG/soilTexture.php', $data);
            }else if($page == 'RD'){
                $data['picts'] = $this->g->getPict('Other','Road & Drainage',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Other','Road & Drainage',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTablePG($pictLoc,'Road & Drainage'));
                $this->load->view('GIS/Other/PG/roadDrainage.php', $data);
            }
        }else if($loc == "Wilayah"){
            if($currLoc == null){
                $pictLoc = "W01";
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbarWilayah.php',array('currLoc' => $currLoc, 'authorization' => $authorization),TRUE);	
            if($page == 'ST'){
                $data['picts'] = $this->g->getPict('Other','Soil Texture',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Other','Soil Texture',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Soil Texture'));
                $this->load->view('GIS/Other/Wilayah/soilTexture.php', $data);
            }else if($page == 'RD'){
                $data['picts'] = $this->g->getPict('Other','Road & Drainage',$pictLoc);
                $data['allPicts'] = $this->g->getAllPict('Other','Road & Drainage',$pictLoc);
                $data['locationTable'] = json_encode($this->g->getLocationTableWilayah($pictLoc,'Road & Drainage'));
                $this->load->view('GIS/Other/Wilayah/roadDrainage.php', $data);
            }
        }else if($loc == "Lokasi"){
            $listLokasi = $this->g->getLokasi();
            if($currLoc == null){
                $pictLoc = $listLokasi[0]->lokasi;
            }else{
                $pictLoc = $currLoc;
            }
            $data['navbar'] = $this->load->view('template/GIS/navbarLokasi.php',array('currLoc' => $currLoc, 'authorization' => $authorization, 'listLokasi' =>$listLokasi), TRUE);
            if($page == 'ST'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('Other','Soil Texture',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('Other','Soil Texture',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('Other','Soil Texture',$pictLoc);
                $this->load->view('GIS/Other/Lokasi/soilTexture.php', $data);
            }else if($page == 'RD'){
                if($date != null){
                    $data['picts'] = $this->g->getPictByDateTime('Other','Road & Drainage',$pictLoc,$date);
                }else{
                    $data['picts'] = $this->g->getPict('Other','Road & Drainage',$pictLoc);
                }
                $data['allPicts'] = $this->g->getAllPict('Other','Road & Drainage',$pictLoc);
                $this->load->view('GIS/Other/Lokasi/roadDrainage.php', $data);
            }
        }
    }
    public function Upload(){
        $uid = $_SESSION['index'];
        $authorization = $this->g->getAuthorization($uid);
        $loc = $this->input->get('loc');
        $currLoc = $this->input->get('currLoc');
        $listLokasi = $this->g->getLokasi();
        $data['loc'] = $loc;
        $data['authorization'] = $authorization;
        $data['page'] = "UPLD";
        $data['currLoc'] = $currLoc;
		$data['script'] = $this->load->view('include/script.php',NULL,TRUE);
		$data['style'] = $this->load->view('include/styleGIS.php',NULL,TRUE);
        $data['header'] = $this->load->view('template/GIS/header.php',NULL,TRUE);
        $data['locationList'] =  json_encode( $listLokasi);
        $data['listLokasi'] = $listLokasi;
       
            
        if($loc == 'PG'){
            $data['navbar'] = $this->load->view('template/GIS/navbar.php',array('currLoc' => $currLoc, 'authorization' => $authorization),TRUE);	
        }else if($loc == 'Wilayah'){
            $data['navbar'] = $this->load->view('template/GIS/navbarWilayah.php',array('currLoc' => $currLoc, 'authorization' => $authorization),TRUE);	
        }else if($loc == 'Lokasi'){
            $data['navbar'] = $this->load->view('template/GIS/navbarLokasi.php',array('currLoc' => $currLoc, 'authorization' => $authorization, 'listLokasi' =>$listLokasi), TRUE);
        }
        $data['modal'] =  $this->load->view('template/logoutModal.php',NULL,TRUE);
        $data['id_photo'] = $this->g->id_photo()->row_array();	
        $this->load->view('GIS/Upload.php', $data);
		
    }
    public function uploadPict(){
        $uid = $_SESSION['index'];
        $kategori =  $this->input->post('kategori');
        $date =  date('Y-m-d H:i:s');
        $jenis = $this->input->post('jenis');
        $extension = $this->input->post('extension');
        $name = $kategori."_".str_replace(array(' ','&'), array('_', '-'),$jenis)."_".$uid."_".str_replace(array(' ',':'), array('_', '-'),$date).".".$extension;
        $pdfname =  $kategori."_".str_replace(array(' ','&'), array('_', '-'),$jenis)."_".$uid."_".str_replace(array(' ',':'), array('_', '-'),$date).".pdf";
        $config = array();
		$config['upload_path']		= './assets/upload/gis_pict/';
		$config['allowed_types']	= 'gif|jpg|png';
		$config['overwrite']		= true;
        $config['file_name'] = $name;
        $this->load->library('upload', $config);

        $this->upload->initialize($config);
        $upload_image = $this->upload->do_upload('image');	
		$location = $this->input->post('location');
        $description =  $this->input->post('description');
        
        $config = array();
        $config['upload_path'] = './assets/upload/gis_pdf/';
        $config['allowed_types'] = 'pdf';
        $config['file_name'] = $pdfname;
        
        $this->upload->initialize($config);
        $upload_pdf = $this->upload->do_upload('pdf');
            
		if($upload_image && $upload_pdf){
			$data = array('upload_data' => $this->upload->data());
			$result= $this->g->simpanUploadImage($location,$jenis,$description,$name,$pdfname,$kategori,$date); 
			echo json_encode($result);
		}else{
            echo "false";
        }
    }
   
    public function uploadImageAndData(){

        $uid = $_SESSION['index'];
        $kategori =  $this->input->post('kategori');
        $date =  date('Y-m-d H:i:s');
        $last_update =  date('Y-m-d');
        $jenis = $this->input->post('jenis');
        $extension = $this->input->post('extension');
        $name = $kategori."_".str_replace(' ','_',$jenis)."_".$uid."_".str_replace(array(' ',':'), array('_', '-'),$date).".".$extension;
        $pdfname =  $kategori."_".str_replace(' ','_',$jenis)."_".$uid."_".str_replace(array(' ',':'), array('_', '-'),$date).".pdf";
        $config = array();
		$config['upload_path']		= './assets/upload/gis_pict/';
		$config['allowed_types']	= 'gif|jpg|png';
		$config['overwrite']		= true;
        $config['file_name'] = $name;
        $this->load->library('upload', $config);

        $this->upload->initialize($config);
        $upload_image = $this->upload->do_upload('image');	
		$location = $this->input->post('location');
        $description =  $this->input->post('description');
        $tableData = json_decode($this->input->post('tbldata'), TRUE);
        $tblname = $this->input->post('tblname');
        
        $config = array();
        $config['upload_path'] = './assets/upload/gis_pdf/';
        $config['allowed_types'] = 'pdf';
        $config['file_name'] = $pdfname;
        
        $this->upload->initialize($config);
        $upload_pdf = $this->upload->do_upload('pdf');

            
		if($upload_image && $upload_pdf){
			$data = array('upload_data' => $this->upload->data());
			$result= $this->g->uploadImageAndData($location,$jenis,$description,$name,$pdfname,$kategori,$date, $last_update, $tblname, $tableData); 
			echo json_encode($result);
		}else{
            echo "false";
        }

        
    }

    public function getPictByDateTime(){
        $date = $this->input->post('date');
        $kategori = $this->input->post('kategori');
        $jenis = $this->input->post('jenis');
        $location = $this->input->post('location');
        $result = $this->g->getPictByDateTime($kategori,$jenis,$location,$date); 
		echo json_encode($result);
    }

    public function getWatterLogging(){
        $photo_id = $this->input->post('photo_id');
        $result = $this->g->getWaterLogging($photo_id);
        echo json_encode($result);
    }

    public function uploadExcel(){
        $excel = $this->input->post('newPostExcel');
        $id_photo =$this->input->post('id_photo');
        if ($_FILES['newPostExcel']['size'] == 0)
        {
            redirect('GIS_Dashboard/Upload?loc=Lokasi');
        } else{
 
        $config = array();
        $config['upload_path'] = './assets/upload/gis_xls/';
        $config['allowed_types'] = 'xls|csv';
        $this->load->library('upload', $config);
        if ($this->upload->do_upload('newPostExcel')) {
            $data = $this->upload->data();
            @chmod($data['full_path'], 0777);

            $this->load->library('Spreadsheet_Excel_Reader');
            $this->spreadsheet_excel_reader->setOutputEncoding('CP1251');

            $this->spreadsheet_excel_reader->read($data['full_path']);
            $sheets = $this->spreadsheet_excel_reader->sheets[0];
            error_reporting(0);

            $data_excel = array();
            for ($i = 2; $i <= $sheets['numRows']; $i++) {
                if ($sheets['cells'][$i][1] == '') break;
                $data_excel[$i - 1]['photo_id']    = $id_photo;
                $data_excel[$i - 1]['lokasi']    = $sheets['cells'][$i][1];
                $data_excel[$i - 1]['luas']   = $sheets['cells'][$i][2];
                $data_excel[$i - 1]['status'] = $sheets['cells'][$i][3];
                $data_excel[$i - 1]['varietas_bibit'] = $sheets['cells'][$i][4];
                $data_excel[$i - 1]['jenis_bibit'] = $sheets['cells'][$i][5];
                $data_excel[$i - 1]['kelas_bibit'] = $sheets['cells'][$i][6];
                $data_excel[$i - 1]['tanggal_awal_perawatan'] = date('Y-m-d',strtotime(str_replace('/','-',str_replace('"','',$sheets['cells'][$i][7]))));
                $data_excel[$i - 1]['rencana_forcing'] = date('Y-m-d',strtotime(str_replace('/','-',str_replace('"','',$sheets['cells'][$i][8]))));
                $data_excel[$i - 1]['tanggal_terbang'] = date('Y-m-d',strtotime(str_replace('/','-',str_replace('"','',$sheets['cells'][$i][9]))));
                $data_excel[$i - 1]['umur_forcing'] = $sheets['cells'][$i][10];
                $data_excel[$i - 1]['plot'] = $sheets['cells'][$i][11];
                $data_excel[$i - 1]['luas_aktif'] = $sheets['cells'][$i][12];
                $data_excel[$i - 1]['rata-rata'] = $sheets['cells'][$i][13];
                $data_excel[$i - 1]['0-0,05'] = $sheets['cells'][$i][14];
                $data_excel[$i - 1]['0,05-0,1'] = $sheets['cells'][$i][15];
                $data_excel[$i - 1]['0,1-0,15'] = $sheets['cells'][$i][16];
                $data_excel[$i - 1]['0,15-0,2'] = $sheets['cells'][$i][17];
                $data_excel[$i - 1]['0,2-0,25'] = $sheets['cells'][$i][18];
                $data_excel[$i - 1]['0,25-0,3'] = $sheets['cells'][$i][19];
                $data_excel[$i - 1]['0,3-0,35'] = $sheets['cells'][$i][20];
                $data_excel[$i - 1]['0,35-0,4'] = $sheets['cells'][$i][21];
                $data_excel[$i - 1]['0,4-0,45'] = $sheets['cells'][$i][22];
                $data_excel[$i - 1]['0,45-0,5'] = $sheets['cells'][$i][23];
                $data_excel[$i - 1]['0,5-0,55'] = $sheets['cells'][$i][24];
                $data_excel[$i - 1]['0,55-0,6'] = $sheets['cells'][$i][25];
                $data_excel[$i - 1]['0,6-0,65'] = $sheets['cells'][$i][26];
                $data_excel[$i - 1]['0,65-0,7'] = $sheets['cells'][$i][27];
                $data_excel[$i - 1]['0,7-0,75'] = $sheets['cells'][$i][28];
                $data_excel[$i - 1]['0,75-0,8'] = $sheets['cells'][$i][29];
                $data_excel[$i - 1]['0,8-0,85'] = $sheets['cells'][$i][30];
                $data_excel[$i - 1]['0,85-0,9'] = $sheets['cells'][$i][31];
                $data_excel[$i - 1]['0,9-0,95'] = $sheets['cells'][$i][32];
                $data_excel[$i - 1]['0,95-1'] = $sheets['cells'][$i][33];
                $data_excel[$i - 1]['1,'] = $sheets['cells'][$i][34];
                $data_excel[$i - 1]['2,'] = $sheets['cells'][$i][35];
                $data_excel[$i - 1]['3,'] = $sheets['cells'][$i][36];
                $data_excel[$i - 1]['4,'] = $sheets['cells'][$i][37];
                $data_excel[$i - 1]['5,'] = $sheets['cells'][$i][38];
                $data_excel[$i - 1]['6,'] = $sheets['cells'][$i][39];
                $data_excel[$i - 1]['1-2'] = $sheets['cells'][$i][40]; 
                $data_excel[$i - 1]['3-4'] = $sheets['cells'][$i][41];
                $data_excel[$i - 1]['5-6'] = $sheets['cells'][$i][42];  
                $data_excel[$i - 1]['tingkat_kehijauan'] = $sheets['cells'][$i][43];     
            }

            $this->db->insert_batch('plant', $data_excel);
            // @unlink($data['full_path']);
            redirect('GIS_Dashboard/Upload?loc=Lokasi');
           
            }
        }
        
        
    }

    function trend_pw(){
        $lokasi = $this->input->post('lokasi',TRUE);
        $data = $this->g->trendpw($lokasi)->result();
        echo json_encode($data);
      }

      function legeda1_pw(){
        $lokasi = $this->input->post('lokasi',TRUE);
        $data = $this->g->legendaspw1($lokasi)->result();
        echo json_encode($data);
      }

      function legeda2_pw(){
        $lokasi = $this->input->post('lokasi',TRUE);
        $data = $this->g->legendapw2($lokasi)->result();
        echo json_encode($data);
      }

      function date_pw(){
        $lokasi = $this->input->post('lokasi',TRUE);
        $data = $this->g->datepw($lokasi)->result();
        echo json_encode($data);
      }
}
