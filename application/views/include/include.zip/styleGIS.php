<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/bootstrap_gis.css');?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/templateGIS.css');?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/fertilizer/styles.css');?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/IconSetLabita/styles.css');?>">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
