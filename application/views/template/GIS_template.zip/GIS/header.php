<!-- Header -->
<nav class="navbar navbar-expand navbar-light bg-light custom-header">
    <a class="nav-link" id="sidebarTogleGIS" role="button" >
        <i class="fa fa-bars" >
        </i>
    </a>

    <!-- Title -->
    <form class="d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 ">
        <div class="input-group" >
            <div id="homeLink1" class="display-none">
                <a href="<?php if (!empty($pg)) echo site_url('WIP_LABITA_BK_Dashboard/plantation_group?page=HOME&pg='.$pg) ?>"><?php  if (!empty($pg)) echo $pg ?></a>
                <span> -&nbsp;</span>
            </div>

            <div id="homeLink2" class="display-none">
                <a href="<?php if (!empty($wilayah)) echo site_url('WIP_LABITA_BK_Dashboard/wilayah?page=HOME&wilayah='.$wilayah.'&pg='.$pg) ?>" ><?php  if (!empty($wilayah)) echo $wilayah ?></a>
                <span>-&nbsp;</span>
            </div>

            <span id="fullTitle" class="d-none d-sm-inline-block">Currently no Text</span>
            <span id="otherTitle" class="d-sm-none">Currently no Text</span>
        </div>
    </form>
    <!-- Title end -->
    <!-- Right header menu -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item mx-2 ">
            <a id="backButton" class="nav-link" role="button" >
                <i class="fa fa-arrow-circle-left fa-lg"></i>
            </a>
        </li>
        <div class="leftcontent"></div>
        <li class="nav-item dropdown no-arrow mx-2 ">
            <a class="nav-link" role="button" id="userDrop" data-toggle="dropdown">
                <i class="fa fa-user-circle fa-lg"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDrop">
                <a id="profileButton" class="dropdown-item" href="#">
                    <i class="fa fa-user mr-3 "></i> Profile </a>
                <a id="mainMenuButton" href="<?php echo site_url('Dashboard') ?>" class="dropdown-item" href="#">
                    <i class="fa fa-bars mr-3 "></i> Main-Menu </a>
                    <div class="dropdown-divider"></div>
                <a id="logOutButton" class="dropdown-item" href="#">
                    <i class="fa fa-sign-out mr-3 "></i> Logout</a>
            </div>
        </li>
    </ul>
    <!-- Right header menu end -->
</nav>
<!-- Header end -->
