 <!-- Sidebar -->

 <style>
   @import url('https://fonts.googleapis.com/css?family=Poppins');

   * {

     margin: 0;
     padding: 0;
     user-select: none;
     box-sizing: border-box;
     font-family: 'Poppins', sans-serif;
   }

   .soilmain {
     color: white;
     font-style: bold;
   }


   .holas ul li .Environtment {

     font-size: 18px;
   }

   .holas ul {

     height: 100%;
     width: 100%;
     list-style: none;

   }

   .holas ul li {
     line-height: 40px;
     border-bottom: 1px solid rgba(255, 255, 255, 0.1);

   }

   .holas ul li a {

     color: white;
     position: relative;
     text-decoration: none;
     font-size: 14px;
     padding-left: 8px;
     padding-right: 5px;
     font-weight: 500;
     display: block;
     width: 100%;
     border-left: 2px solid transparent;
   }

   .holas ul ul {
     position: static;
     display: none;
   }

   .holas ul .feat-show.show {

     display: block;

   }

   .holas ul .feat2-show.show {

     display: block;

   }

   .holas ul .digishow.show {

     display: block;

   }

   .holas ul .envishow.show {

     display: block;

   }

   .holas ul .serv-show.show {

     display: block;

   }

   .holas ul ul li {
     line-height: 42px;
     border-bottom: none;
   }

   .holas ul ul li a {
     font-size: 13px;
     color: #e6e6e6;
     padding-left: 20px;

   }

   .holas ul .fruitshow.show {

     display: block;

   }

   .holas ul .airparams.show {

     display: block;

   }

   .holas ul .soilparams.show {

     display: block;

   }


   .holas ul .secondenviclass.show {

     display: block;

   }

   .holas ul .threeenviclass.show {

     display: block;

   }

   .holas ul li .Fruit {
     font-size: 18px;

   }

   .holas ul li .Resume {
     font-size: 18px;

   }

   .holas ul li a span {

     position: absolute;
     top: 50%;
     right: 20px;
     transform: translateY(-50%) rotate(-180deg);
     font-size: 15px;
     transition: transform 0.4s;
   }

   .holas ul li a span.rotate {

     transform: translateY(-50%) rotate(1deg);
   }

   .holas ul li .soilmain {

     font-size: 18px;
   }

   .holas ul li .serv-btn {

     font-size: 18px;
   }

   .holas ul li a:hover {

     color: yellow;
     background: rgba(255, 255, 255, 0.1);
   }

   .active {
     background: #9ACD32;
     color: yellow !important;
   }

   .navbar {
     overflow-y: scroll;
   }

   .navbar::-webkit-scrollbar {
     display: none;
   }

   .shield {
     position: relative;
     width: 140px;
     height: 150px;
     background-color: #fff;
     border-radius: 0 0 140px 140px;
     display: inline-block;
   }

   .shield:before,
   .shield:after {
     position: absolute;
     margin-top: 50px;
     content: "";
     left: 70px;
     top: 0;
     width: 70px;
     height: 90px;
     border-radius: 100px 100px 0 0;
     -webkit-transform: rotate(-60deg);
     -moz-transform: rotate(-60deg);
     -ms-transform: rotate(-60deg);
     -o-transform: rotate(-60deg);
     transform: rotate(-60deg);
     -webkit-transform-origin: 0 100%;
     -moz-transform-origin: 0 100%;
     -ms-transform-origin: 0 100%;
     -o-transform-origin: 0 100%;
     transform-origin: 0 100%;
   }

   .shield:after {
     left: 0;
     -webkit-transform: rotate(60deg);
     -moz-transform: rotate(60deg);
     -ms-transform: rotate(60deg);
     -o-transform: rotate(60deg);
     transform: rotate(60deg);
     -webkit-transform-origin: 100% 100%;
     -moz-transform-origin: 100% 100%;
     -ms-transform-origin: 100% 100%;
     -o-transform-origin: 100% 100%;
     transform-origin: 100% 100%;
   }
 </style>

 <nav class="navbar gis-custom-sidebar gis-custom-sidebar-fullsize" id="sidebar" style="background: #008000;">
   <ul class="navbar-nav sidebar-nav-gis" id="sidebarAccordion">
   <a href="<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/NDVI?page=HOME&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/NDVI?page=HOME&loc=PG') ?>" class="shield ml-4">
       <img src="<?php echo base_url()?>/assets/images/gis_logo/logo.png"
         style="width:98%; height:98%; margin-left:1.4px"></a>
     <a class="gis-nav-title">
       <span>Location</span>
       <div class="px-0 input-lokasi-gis">
         <select class="form-control select2" name="lokasiGis" id="lokasiGis">
           <option value="PG1">Plant Group 1</option>
           <option value="PG2">Plant Group 2</option>
           <option value="PG3">Plant Group 3</option>
         </select>
       </div>
     </a>


     <a class="gis-nav-subtitle">
     </a>

     <div class="holas">
       <ul>
         <li><a id="soil" class="soilmain" href="#">
             <i id="icon" class="fas fa-map "></i>
             Soil
             <span class="fas fa-caret-down firstsoil ml-2"></span></a>

           <ul class="digishow" id="sub-soil">
             <li>
               <a href="#" id="icon" class="feat-btn mr-2">Digital Surface Model<span
                   class="fas fa-caret-down first ml-2"></span>
               </a>
               <ul class="feat-show" id="sub-dsm">
                 <li id="rgb"><a class="menu"
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/DSM?page=RGB&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/DSM?page=RGB&loc=PG') ?>'>RGB</a>
                 </li>
                 <li id="wd"><a class="menu"
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/DSM?page=WD&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/DSM?page=WD&loc=PG') ?>'>Water
                     Direction</a></li>
                 <li id="wf"><a class="menu"
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/DSM?page=WF&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/DSM?page=WF&loc=PG') ?>'>Water
                     Flow</a></li>
                 <li id="wl"><a class="menu"
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/DSM?page=WL&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/DSM?page=WL&loc=PG') ?>'>Water
                     Logging</a></li>
                 <li id="dl"><a class="menu"
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/DSM?page=DL&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/DSM?page=DL&loc=PG') ?>'>Design
                     Location</a></li>
                 <li id="dd"><a class="menu"
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/DSM?page=DD&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/DSM?page=DD&loc=PG') ?>'>Design
                     Deal</a></li>
               </ul>
             </li>

             <li>
               <a href="#" class="feat-btn2 mr-2">Soil Properties<span class="fas fa-caret-down first2 ml-2"></span>
               </a>
               <ul class="feat2-show">
                 <li><a href="#">Soil Chemical</a></li>
                 <li><a href="#">Soil Physical</a></li>
               </ul>
             </li>
           </ul>
         </li>

         <li>
           <a id="plant" class="serv-btn" href="#"> <i class="fas fa-seedling"></i> Plant
             <span class="fas fa-caret-down second"></span>
           </a>
           <ul class="serv-show" id="sub-plant">
             <li id="pw"><a
                 href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/NDVI?page=PW&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/NDVI?page=PW&loc=PG') ?>'>Plant
                 Weight</a></li>
             <li id="pd"><a
                 href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/NDVI?page=PD&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/NDVI?page=PD&loc=PG') ?>'>Plant
                 Disease</a></li>
             <li id="sow"><a
                 href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/NDVI?page=SOW&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/NDVI?page=SOW&loc=PG') ?>'>Sufficient
                 Of Water</a></li>
             <li id="sug"><a
                 href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/NDVI?page=SUG&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/NDVI?page=SUG&loc=PG') ?>'>Sugestion</a>
             </li>
           </ul>
         </li>

         <li><a class="Fruit" href="#"><i class="fas fa-apple-alt"></i> Fruit<span
               class="fas fa-caret-down firstfruit ml-2"></a>
           <ul class="fruitshow">
             <li><a href="#">Distribution</a></li>
             <li><a href="#">Population</a></li>
           </ul>
         </li>
         <li>
           <a id="envi" href="#" class="Environtment"><i class="fas fa-microchip"></i> Environtment<span
               class="fas fa-caret-down firstenvi ml-2">
           </a>

           <ul class="envishow">
             <li><a id="param" class="airparams" href='#'>Air Parameters<span
                   class="fas fa-caret-down secondenvi ml-2"></a>
               <ul class="secondenviclass">
                 <li><a id="hu"
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/Sensor?page=HU&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/Sensor?page=HU&loc=PG') ?>'>Air
                     Humidity</a></li>
                 <li id="at"><a
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/Sensor?page=HU&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/Sensor?page=HU&loc=PG') ?>'>Air
                     Temperature</a></li>
                 <li><a href="#">Bud Leaf Time</a></li>
                 <li id="rf"><a
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/Sensor?page=RF&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/Sensor?page=RF&loc=PG') ?>'>Rain
                     Fall</a></li>
                 <li><a href="#">UV Radiation</a></li>

               </ul>
             </li>

             <li><a id="sp" class="soilparams" href='#'>Soil Parameters<span
                   class="fas fa-caret-down threeenvi ml-2"></a>
               <ul class="threeenviclass">
                 <li><a href="#">Baterry Level</a></li>
                 <li><a href="#">Soil EC</a></li>
                 <li id="tm"><a
                     href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/Sensor?page=TM&loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/Sensor?page=TM&loc=PG') ?>'>Soil
                     Temperature</a></li>
                 <li><a href="#">Soil PH</a></li>
                 <li><a href="#">Lagoon Water Level</a></li>
               </ul>
             </li>
           </ul>
         </li>
         <li><a class="Resume" href="#"><i class="fas fa-check-square"></i> Resume</a>
           <!--  <li><a href="#">Sensor</a></li> -->
       </ul>
     </div>
     <li class="nav-item" style='margin-top:auto' id="uploadButton">
       <a class="nav-link gis-sidebar-button-item"
         href='<?php echo site_url(isset($currLoc) ? 'GIS_Dashboard/Upload?loc=PG&currLoc='.$currLoc : 'GIS_Dashboard/Upload?loc=PG') ?>'
         style=" <?php echo (($authorization[0]->authorization != '' && $authorization[0]->authorization != null) ? '' : 'display:none') ?>">
         <i class="fa fa-upload fa-lg link-icon" style="margin-left:10px;"></i>
         <span>Upload Photo</span>
       </a>
     </li>
   </ul>
 </nav>
 <!-- Sidebar end -->

 <script>
   $(document).ready(function () {

     var url = new URL(document.location);
     var params = url.searchParams;
     var page = params.get("page");

     if (page == "HOME") {
       $("#soil").addClass('active');
     } else if (page == "WF") {
       $("#wf").addClass('active');
       $("#soil").addClass('active');
       $("#sub-soil").addClass('show');
       $("#sub-dsm").addClass('show');

     } else if (page == "DL") {
       $("#dl").addClass('active');
       $("#soil").addClass('active');
       $("#sub-soil").addClass('show');
       $("#sub-dsm").addClass('show');

     } else if (page == "WD") {
       $("#wd").addClass('active');
       $("#soil").addClass('active');
       $("#sub-soil").addClass('show');
       $("#sub-dsm").addClass('show');

     } else if (page == "WL") {
       $("#wl").addClass('active');
       $("#soil").addClass('active');
       $("#sub-soil").addClass('show');
       $("#sub-dsm").addClass('show');

     } else if (page == "DD") {
       $("#dd").addClass('active');
       $("#soil").addClass('active');
       $("#sub-soil").addClass('show');
       $("#sub-dsm").addClass('show');

     } else if (page == "RGB") {
       $("#rgb").addClass('active');
       $("#soil").addClass('active');
       $("#sub-soil").addClass('show');
       $("#sub-dsm").addClass('show');

     } else if (page == "PW") {
       $("#pw").addClass('active');
       $("#plant").addClass('active');
       $("#sub-plant").addClass('show');

     } else if (page == "PD") {
       $("#pd").addClass('active');
       $("#plant").addClass('active');
       $("#sub-plant").addClass('show');

     } else if (page == "HU") {
       $("#hu").addClass('active');
       $("#param").addClass('active');
       $("#envi").addClass('active');

     } else if (page == "LWL") {
       $("#lwl").addClass('active');
       $("#envi").addClass('active');

     } else if (page == "SM") {
       $("#sm").addClass('active');
       $("#envi").addClass('active');

     } else if (page == "TM") {
       $("#tm").addClass('active');
       $("#envi").addClass('active');

     } else if (page == "SOW") {
       $("#sow").addClass('active');
       $("#plant").addClass('active');
       $("#sub-plant").addClass('show');

     } else if (page == "RF") {
       $("#rf").addClass('active');
       $("#envi").addClass('active');

     } else if (page == "SUG") {
       $("#sug").addClass('active');
       $("#plant").addClass('active');
       $("#sub-plant").addClass('show');

     }


   });


   $('.feat-btn').click(function () {
     $('.holas ul .feat-show').toggleClass("show");
     $('.holas ul .first').toggleClass("rotate");

   });

   $('.Fruit').click(function () {
     $('.holas ul .fruitshow').toggleClass("show");
     $('.holas ul .firstfruit').toggleClass("rotate");

   });
   $('.feat-btn2').click(function () {
     $('.holas ul .feat2-show').toggleClass("show");
     $('.holas ul .first2').toggleClass("rotate");

   });
   $('.soilmain').click(function () {
     $('.holas ul .digishow').toggleClass("show");
     $('.holas ul .firstsoil').toggleClass("rotate");

   });
   $('.Environtment').click(function () {
     $('.holas ul .envishow').toggleClass("show");
     $('.holas ul .firstenvi').toggleClass("rotate");

   });

   $('.airparams').click(function () {
     $('.holas ul .secondenviclass').toggleClass("show");
     $('.holas ul .secondenvi').toggleClass("rotate");

   });

   $('.soilparams').click(function () {
     $('.holas ul .threeenviclass').toggleClass("show");
     $('.holas ul .threeenvi').toggleClass("rotate");

   });


   $('.serv-btn').click(function () {
     $('.holas ul .serv-show').toggleClass("show");
     $('.holas ul .second').toggleClass("rotate");

   });
 </script>