<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Log Out</h4>
        </div>
        <div class="modal-body">
          <p>Press "Logout" to end your current session</p>
        </div>
        <div class="modal-footer">
            <a role="button" href='<?php echo site_url('WIP_LABITA_BK_MainMenu/logout') ?>'class="btn btn-primary">Logout</a>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>