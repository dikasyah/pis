<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Digital Plantation - PIS</title>
	<link rel="icon" href="<?=base_url()?>/assets/images/logo-ggf.png" type="image/png">
	<script>
		var site_url = '<?=site_url()?>';
		var base_url = '<?=base_url()?>';
		var page = '<?=$page?>';
		var loc = '<?=$loc?>';
		var subpage = '<?=$subpage?>';
		var currLoc = '<?=$currLoc?>';
		var pageDate = '<?=$pageDate?>';
	</script>
	<style type="text/css">
		::selection {
			background-color: #E13300;
			color: white;
		}

		::-moz-selection {
			background-color: #E13300;
			color: white;
		}

		body {
			background-color: #fff;
			margin: 40px;
			font: 13px/20px normal Helvetica, Arial, sans-serif;
			color: #4F5155;
		}

		a {
			color: #003399;
			background-color: transparent;
			font-weight: normal;
		}

		h1 {
			color: #444;
			background-color: transparent;
			border-bottom: 1px solid #D0D0D0;
			font-size: 19px;
			font-weight: normal;
			margin: 0 0 14px 0;
			padding: 14px 15px 10px 15px;
		}


		code {
			font-family: Consolas, Monaco, Courier New, Courier, monospace;
			font-size: 12px;
			background-color: #f9f9f9;
			border: 1px solid #D0D0D0;
			color: #002166;
			display: block;
			margin: 14px 0 14px 0;
			padding: 12px 10px 12px 10px;
		}

		#body {
			margin: 0 15px 0 15px;

		}


		p.footer {
			text-align: right;
			font-size: 11px;
			border-top: 1px solid #D0D0D0;
			line-height: 32px;
			padding: 0 10px 0 10px;
			margin: 20px 0 0 0;
		}


		#container {
			margin: 5px;
			border: 1px solid #D0D0D0;
			box-shadow: 0 0 8px #D0D0D0;
		}

		#line_ven {
			width: 100%;
			height: 400px;
		}
	</style>
	<?php
		echo $style;
		echo $script;
	?>

</head>

<body>
	<div id="wrapper">
		<?php echo $navbar; ?>
		<div id="content" class="gis-content gis-content-fullsize">
			<?php echo $header; ?>
			<!--Main content-->
			<div class="row ml-1">
				<div class="col-lg-8 gis-card-padding-leftside">
					<select class="form-control" id="myCurrPictselector">
						
					</select>
				</div>
				<div class="col-lg-4 gis-card-padding-rightside">

					<a id="pdfDownloadButton"
						class="btn btn-primary full-width">Download pdf</a>
				</div>
			</div>

			<div id="dem"></div>
			<div class="row gis-card-padding-leftside">
				<div class="col-lg-12 ">
					<div class="card full-wdith">
						<div class="card-header  py-0 pict-header">
							<span id="Title" class="submenu-main-title-gis">NDVI</span>
							<span id="pictDate"
								class="submenu-main-title-gis"></span>
							<span id="spaceFiller" class="header-blank-space">NDVI</span>
						</div>
						<div class="card-body p-0">
							<div class="pict-overlay-type1" id="pictOverlayGis">
							</div>
							<img id="mainContentImage"
								src=""
								style="width:100%; height:100%;">
						</div>
					</div>
				</div>
			</div>

			<div class="row  gis-card-padding-leftside">
				<div class="col-lg-8">
					<div class="card full-wdith">
						<div class="card-header py-0">
							<span class="submenu-title-gis">Trend History</span>
						</div>
						<div class="card-body">
							<div id="line_ven"></div>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="card full-wdith">
						<div class="card-header py-0">
							<span class="submenu-title-gis">Legend</span>
						</div>
						<div class="card-body mt-2">
							<table style="width:100%; height:380px; border: 1px solid black;">
								<tr  style="width:100%; border: 1px solid black;">
									<td style="background-color: #0ec208; padding:3px;"></td>
									<td style=" border: 1px solid black; text-align:center;">1</td>
									<td style=" border: 1px solid black; text-align:center;"id="satu"></td>
									<td rowspan="2" style="background-color: #0ec208; padding:3px;"></td>
									<td rowspan="2" style="border: 1px solid black;  text-align:center;"id="satu1"></td>
								</tr>
								<tr>
									<td style="background-color: #79fa00; padding:3px;"></td>
									<td style=" border: 1px solid black; text-align:center;">2</td>
									<td style=" border: 1px solid black; text-align:center;" id="dua"></td>
									
								</tr>
								<tr  style="width:100%; border: 1px solid black;">
									<td style="background-color: #fae100; padding:3px;"></td>
									<td style="border: 1px solid black; text-align:center;">3</td>
									<td style=" border: 1px solid black; text-align:center;" id="tiga"></td>
									<td rowspan="2" style="background-color: #fabb00; padding:3px;"></td>
									<td rowspan="2" style="border: 1px solid black;  text-align:center;" id="dua1"></td>
								</tr>
								<tr  style="width:100%; border: 1px solid black;">
									<td style="background-color: #fabb00; padding:3px;"></td>
									<td style="border: 1px solid black; text-align:center;">4</td>
									<td style="border: 1px solid black; text-align:center" id="empat"></td>
								</tr>
								<tr  style="width:100%; border: 1px solid black;">
									<td style="background-color: #fa6400; padding:8px;"></td>
									<td style="border: 1px solid black; text-align:center;">5</td>
									<td style=" border: 1px solid black; text-align:center;"id="lima"></td>
									<td rowspan="2" style="background-color: #fa1100; padding:8px;"></td>
									<td rowspan="2" style="border: 1px solid black;  text-align:center;"id="tiga1"></td>
								</tr>
								<tr  style="width:100%; border: 1px solid black;">
									<td style="background-color: #fa1100; padding:3px;"></td>
									<td style="border: 1px solid black;  text-align:center;">6</td>
									<td style=" border: 1px solid black;  text-align:center;" id="enam"></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
			</div>

			<div class="row gis-card-padding-leftside ">
				<div class="col-lg-12">
					<div class="card full-wdith">
						<div class="card-header py-0">
							<span class="submenu-title-gis">Executive Summary</span>
						</div>
						<div class="card-body pt-1 pb-3 px-3">
							<div class="desc-container">
								<span id="executiveDescription"
									class="breakable-line"><?php echo isset($picts[0]->description) && preg_replace('/\s+/', '', $picts[0]->description) !='' ? $picts[0]->description : 'Currently no Summary at this location'; ?></span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--Main content End-->
			<div class="mypanel"></div>
		</div>
	</div>
	<!-- pop up  -->
	<div class="pop" id="pictModal">
		<div class="modal-header">
			<p class="pop-header-filler">&times;</p>
			<div class="pop-header-text-container">
				<div class="title-pop" id="pictPopTitle">NDVI</div>
				<div class="title-pop" id="pictPopDate"><?php echo isset($picts[0]->date) ? $picts[0]->date : '-'; ?>
				</div>
			</div>
			<button class="close-button" onclick="popClose('pictModal')">&times;</button>

		</div>
		<div class="modal-body" style="height:100% important;">
			<img id="popPict"
				src=""
				style="height:100%; object-fit: contain; width:100%;">
		</div>
	</div>
	<div class="pop-alert-upload" id="unModal">
		<div class="modal-header">
			<div class="title">Alert</div>
			<button class="close-button" onclick="popClose('unModal')">&times;</button>
		</div>
		<div class="modal-body">
			<p>Currently pdf file doesn't exist on this location</p>
		</div>
	</div>
	<!--overlay for pop-->
	<div class="" id="overlay"></div>
	<!--overlay for pop end-->
	<!-- pop up end -->
	<?php echo $modal; ?>
	<script>
		document.querySelector("#fullTitle").innerHTML = "WEB - Geographic Information System";
		document.querySelector("#otherTitle").innerHTML = "WEB - GIS";
		$("#NDVI2").removeClass('inactive');
		$("#NDVI2").addClass('active');
		$("#mainNDVI").parent().addClass('show-sub');
		$('.select2').select2();
		$('>span>span>span', '.select2').css({
			"color": "white",
			"font-size": "18px",
			"font-weight": "500"
		})
	</script>
	
	<script src="<?php echo base_url('/assets/js/chart_gis/ndvi_control.js');?>"></script>
	<script src="<?php echo base_url('/assets/js/templateUI_GIS.js');?>"></script>
</body>

</html>